package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class StudentService {

    public int addMarks(int a, int b) {
        return a + b;
    }

    public int divideMarks(int a, int b) {
        return a / b;
    }
}