package com.example.demo;

import org.junit.jupiter.api.Test;

import com.example.demo.service.StudentService;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StudentServiceTest {

    StudentService service = new StudentService();

    @Test
    void testAddMarks() {
        assertEquals(50, service.addMarks(20, 30));
    }
}