package com.example.jobapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.jobapp.entity.Application;

public interface ApplicationRepository
        extends JpaRepository<Application, Integer> {

    boolean existsByStudentIdAndJobId(
            int studentId,
            int jobId);
}