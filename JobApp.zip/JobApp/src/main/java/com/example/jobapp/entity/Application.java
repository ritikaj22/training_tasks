package com.example.jobapp.entity;

import jakarta.persistence.*;

@Entity
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String applicationDate;
    private String status;
    private Integer studentId;

    @ManyToOne
    @JoinColumn(name = "job_id")

    private Job job;

    public Application() {
    }
    public Application(Integer id, String applicationDate, String status, Integer studentId, Job job) {
		super();
		this.id = id;
		this.applicationDate = applicationDate;
		this.status = status;
		this.studentId = studentId;
		this.job = job;
	}
    public int getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getApplicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(
            String applicationDate) {

        this.applicationDate = applicationDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }
}