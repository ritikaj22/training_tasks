package com.example.jobapp.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jobapp.dto.ApplicationRequest;
import com.example.jobapp.entity.Application;
import com.example.jobapp.entity.Job;
import com.example.jobapp.repository.ApplicationRepository;
import com.example.jobapp.repository.JobRepository;

@Service
public class ApplicationService {

    @Autowired
    ApplicationRepository appRepo;

    @Autowired
    JobRepository jobRepo;

    public String apply(
            ApplicationRequest req) {

        Job job = jobRepo.findById(
                req.getJobId())

                .orElseThrow(() ->
                        new RuntimeException(
                                "Job Not Found"));

        boolean exists =
                appRepo.existsByStudentIdAndJobId(
                        req.getStudentId(),
                        req.getJobId());

        if(exists) {
            throw new RuntimeException(
                    "Already Applied");
        }

        Application app =
                new Application();

        app.setStudentId(
                req.getStudentId());

        app.setApplicationDate(
                LocalDate.now().toString());

        app.setStatus("APPLIED");

        app.setJob(job);

        appRepo.save(app);

        return "Applied Successfully";
    }

    public List<Application> getAll() {
        return appRepo.findAll();
    }
}