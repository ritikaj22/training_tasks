package com.example.jobapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jobapp.entity.Job;
import com.example.jobapp.repository.JobRepository;

@Service
public class JobService {

    @Autowired
    JobRepository repo;

    public Job save(Job job) {
        return repo.save(job);
    }

    public List<Job> getAll() {
        return repo.findAll();
    }
}