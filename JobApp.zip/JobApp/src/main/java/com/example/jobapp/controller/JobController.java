package com.example.jobapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.jobapp.entity.Job;
import com.example.jobapp.service.JobService;

@RestController
@RequestMapping("/jobs")
public class JobController {

    @Autowired
    JobService service;

    @PostMapping
    public Job addJob(
            @RequestBody Job job) {

        return service.save(job);
    }

    @GetMapping
    public List<Job> getAll() {
        return service.getAll();
    }
}