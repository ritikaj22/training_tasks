package com.example.jobapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.jobapp.entity.Job;

public interface JobRepository
        extends JpaRepository<Job, Integer> {

}
