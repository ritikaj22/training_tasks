package com.example.secureapi;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.*;
import org.mockito.*;

import com.example.secureapi.entity.User;
import com.example.secureapi.repository.UserRepository;
import com.example.secureapi.service.UserService;

public class UserServiceTest {

    @Mock
    UserRepository repo;

    @InjectMocks
    UserService service;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testLoginSuccess() {

        User user = new User();

        user.setUsername("ritika");

        user.setPassword(
                new org.springframework
                .security.crypto.bcrypt
                .BCryptPasswordEncoder()
                .encode("123"));

        when(repo.findByUsername("ritika"))
                .thenReturn(Optional.of(user));

        boolean result =
                service.login("ritika", "123");

        assertTrue(result);
    }
}