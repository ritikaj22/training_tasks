package com.example.secureapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import com.example.secureapi.dto.LoginRequest;
import com.example.secureapi.entity.User;
import com.example.secureapi.security.JwtUtil;
import com.example.secureapi.service.UserService;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    UserService service;

    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return service.register(user);
    }

    @PostMapping("/login")
    public String login(
            @RequestBody LoginRequest req) {

        boolean valid =
                service.login(
                        req.getUsername(),
                        req.getPassword());

        if(valid) {
            return JwtUtil.generateToken(
                    req.getUsername());
        }

        return "Invalid Credentials";
    }

    @GetMapping("/users")
    public Page<User> getUsers(
            @RequestParam int page,
            @RequestParam int size) {

        return service.getUsers(page, size);
    }

    @GetMapping("/admin/dashboard")
    public String dashboard() {
        return "Welcome Admin";
    }
}