package com.example.secureapi.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.secureapi.entity.User;
import com.example.secureapi.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    UserRepository repo;

    BCryptPasswordEncoder encoder =
            new BCryptPasswordEncoder();

    public User register(User user) {

        user.setPassword(
                encoder.encode(user.getPassword()));

        return repo.save(user);
    }

    public boolean login(
            String username,
            String password) {

        Optional<User> optional =
                repo.findByUsername(username);

        if(optional.isEmpty()) {
            return false;
        }

        User user = optional.get();

        return encoder.matches(
                password,
                user.getPassword());
    }

    public Page<User> getUsers(
            int page,
            int size) {

        Pageable pageable =
                PageRequest.of(page, size);

        return repo.findAll(pageable);
    }
}