package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    StudentRepository repo;

    public Student save(Student s) {
        return repo.save(s);
    }

    public List<Student> getAll() {
        return repo.findAll();
    }

    public Student getById(int id) {
        return repo.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Student Not Found"));
    }

    public void delete(int id) {
        repo.deleteById(id);
    }

    public List<Student> getByBranch(String branch) {
        return repo.findByBranch(branch);
    }
}