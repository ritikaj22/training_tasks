package com.example.demo.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank(message = "Name cannot be empty")
    private String name;

    @Email(message = "Invalid Email")
    @NotBlank(message = "Email required")
    private String email;

    @NotBlank(message = "Branch required")
    private String branch;

    @Min(value = 1, message = "CGPA too low")
    @Max(value = 10, message = "CGPA cannot exceed 10")
    private double cgpa;

public Student() {}

	public Student(Integer id, String name, String email, String branch, double cgpa) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.branch = branch;
		this.cgpa = cgpa;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getCgpa() {
		return cgpa;
	}

	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", email=" + email + ", branch=" + branch + ", cgpa=" + cgpa
				+ "]";
	}

}